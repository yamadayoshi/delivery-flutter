import 'package:intl/intl.dart';

class Constants {
  static final currency = new NumberFormat("#,##0.00", "pt_BR");
}